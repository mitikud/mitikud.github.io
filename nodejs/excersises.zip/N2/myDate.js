let myDate = function(){
    return Date();
};
module.exports.myDate = myDate;